const { Client, GatewayIntentBits } = require('discord.js');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMembers
    ]
});

// استدعاء ملف الأوامر والأسئلة لكي لا ينقطع الكود
require('./commands.js')(client);

// ضع هنا التوكن الجديد الذي قمت بعمل Reset له
client.login('MTU0NTAxNTM3ODAxNzc4ODAwNA.G6gr_B.PEEMOaxuOo_KMXAdJ7vhoEGC3OAP4LUO9tUI_4');
