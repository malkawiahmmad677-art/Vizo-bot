module.exports = {
    // رابط المونجو الخاص بك
    mongoURI: "mongodb+srv://mybot:malkawi5678@free-tier-demo.abzmevi.mongodb.net/?appName=free-tier-demo",
    
    // أيديات الرتب المصرح لها
    allowedRoles: [
        '1550404534973501480',
        '1550397337719803944',
        '1551180127440994375',
        '1549972402639732776',
        '1549972290467266731'
    ],

    // توكن البوت يجب أن يكون خارج المصفوفة كمتجر مستقل
    TOKEN: "MTU1ODM4MzA0MTkyNjEzOTk2NA.Gjy5On.Fydnm5N145JRR2L73Lz6Fp1Uz-7rtx5oLiayrI"
};