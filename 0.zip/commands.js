const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = function(client) {
    const PREFIX = '+'; 
    const TICKET_CATEGORY_ID = '1547860968610996245'; 
    const ADMIN_ROLE_ID = '1550395464862400552';
    const LOG_APPLY_CHANNEL_ID = '1554136033438728303'; 
    const GENERAL_LOG_CHANNEL_ID = '1547873602404093982';

    const ROLES_TO_GIVE = ['1549972118278635592', '1550400974500397126', '1550395464862400552'];

    // لحفظ بيانات الاستلام والاستدعاء ومهلة التقديم في الذاكرة
    const ticketClaimers = new Map(); // channelId -> userId
    const lastSummonTime = new Map(); // channelId -> timestamp
    const applyCooldowns = new Map(); // userId -> timestamp

    const APPLY_QUESTIONS = [
        '✍️ **1 - مـــــا اســـــمـــــك ؟**',
        '⏳ **2 - كـــــم عـــــمـــــرك ؟**',
        '🌍 **3 - مِـــــنْ أَيْـــــنَ ؟**',
        '📊 **4 - فـي أَيْـــــشٍ  تَـــــفِـــــيدُنَـــــا ؟**',
        '🛠️ **5 - مَـــــا خِـــــبْـــــرَاتُـــــكَ ؟**',
        '⚡ **6 - هَـــــلْ  أَنْـــــتَ.  مُـــــبَـــــرْمِـــــجٌ قَـــــوِيٌّ ؟**'
    ];

    client.once('ready', () => {
        console.log(`✅ تم تشغيل البوت بنجاح باسم: ${client.user.tag}`);
    });

    client.on('messageCreate', async (message) => {
        if (message.author.bot || !message.content.startsWith(PREFIX)) return;
        const args = message.content.slice(PREFIX.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();

        if (command === 't') {
            if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return message.reply('❌ هـــــذا الاصـــــل مُـــــخَـــــصَّـــــص لِـــــلإِدَارَة فَـــــقَـــــط !');
            }
            const ticketEmbed = new EmbedBuilder()
                .setTitle('الـــــدَّعْـــــم الْـــــفَـــــنِّـــــي')
                .setDescription(
                    '**يرجى الضغط على احد الأزرار ادناه لفتح تذكرة:**\n\n' +
                    '❓ - **مـــــســـــاعـــــدة**\n' +
                    '🚨 - **الـتَّـــشْـــهِـــيـــرِ**\n' +
                    '📝 - **تـــــقـــــديـــــم**\n\n' +
                    '**مـــلـــاحـظــــات:**\n' +
                    '1 - مَـــــمْـــــنُـــــوع اِلْاِسْـــــتِـــــهْـــــبَـــــالِ بِـــــالـتِّـــــكِـــــتِ\n' +
                    '2 - مَـــــمْـــــنُـــــوع  تـــــفْـــــتَـــــحُـــــهُ مَـــــمْـــــرَّتَــــيـــــن\n' +
                    '3 - لَـــــوْ اَلـسَّـــــبَـــــب كَـــــانَ تَـــــافِـــــهًـــــا يَـــــتِـــــمُّ إِغْـــــلَاق اَلـتِّـــــكِـــــتِ'
                )
                .setColor('#2f3136');

            const buttonsRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('ticket_help').setLabel('مـــــســــاعــــــدة').setStyle(ButtonStyle.Primary).setEmoji('❓'),
                new ButtonBuilder().setCustomId('ticket_report').setLabel('تــــــشـــــــهــــــيــــرِ').setStyle(ButtonStyle.Danger).setEmoji('🚨'),
                new ButtonBuilder().setCustomId('ticket_apply').setLabel('تـــــقـــــديـــــم').setStyle(ButtonStyle.Success).setEmoji('📝')
            );
            await message.channel.send({ embeds: [ticketEmbed], components: [buttonsRow] });
            await message.delete().catch(() => {});
        }
    });

    client.on('interactionCreate', async (interaction) => {
        // Handle Modal Submission for Summons
        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'summon_modal') {
                await interaction.deferReply({ ephemeral: true });
                const userInput = interaction.fields.getTextInputValue('summon_user_input').trim();
                let memberToSummon = null;

                try {
                    const cleanId = userInput.replace(/[<@!>]/g, '');
                    memberToSummon = await interaction.guild.members.fetch(cleanId).catch(() => null);
                } catch (e) {}

                if (!memberToSummon) {
                    return interaction.editReply({ content: '❌ لَمْ يَتِمَّ العَثُورُ عَلَى العُضْوِ! التَأَكُّدُ مِنْ الآيدي أَوْ اليُوزَر نِيم الصحيح.' });
                }

                await interaction.channel.permissionOverwrites.edit(memberToSummon.id, {
                    ViewChannel: true,
                    SendMessages: true
                });

                lastSummonTime.set(interaction.channel.id, Date.now());

                await memberToSummon.send({
                    content: `📢 **تَمَّ اسْتِدْعَاؤُكَ إِلَى التَّذْكِرَة:** <#${interaction.channel.id}> فِي سِيرْفَر **${interaction.guild.name}** بِوَاسِطَة: <@${interaction.user.id}>`
                }).catch(() => {});

                await interaction.channel.send({
                    content: `📢 <@${memberToSummon.id}>، تَمَّ اسْتِدْعَاؤُكَ إِلَى هَذِهِ التَّذْكِرَةِ بِوَاسِطَة <@${interaction.user.id}>.`
                });

                return interaction.editReply({ content: `✅ تَمَّ اسْتِدْعَاءُ <@${memberToSummon.id}> وَإِرْسَالُ رِسَالَةٍ خَاصَّةٍ لَهُ!` });
            }
        }

        if (!interaction.isButton()) return;

        // Ticket Creation (Help & Report)
        if (interaction.customId === 'ticket_help' || interaction.customId === 'ticket_report') {
            await interaction.deferReply({ ephemeral: true });

            const existingChannel = interaction.guild.channels.cache.find(
                c => c.parentId === TICKET_CATEGORY_ID && c.permissionOverwrites.cache.has(interaction.user.id)
            );

            if (existingChannel) {
                return interaction.editReply({ content: `❌ **لَدَيْكَ تَذْكِرَةٌ مَفْتُوحَةٌ بِالفِعْلِ هُنَا:** <#${existingChannel.id}>! لا يُنْكِنُكَ فَتْحُ تَذْكِرَةٍ أُخْرَى حَتَّى تُغْلَقَ الأُولَى.` });
            }

            const typeLabel = interaction.customId === 'ticket_help' ? 'مـــــســـــاعـــــدة' : 'تَـــــشْـــــهِـــــيـــــر';
            try {
                const ticketChannel = await interaction.guild.channels.create({
                    name: `ticket-${interaction.customId === 'ticket_help' ? 'help' : 'report'}-${interaction.user.username}`,
                    type: ChannelType.GuildText,
                    parent: TICKET_CATEGORY_ID,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
                        { id: ADMIN_ROLE_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
                    ]
                });

                // إمبد التكت الجديد
                const innerEmbed = new EmbedBuilder()
                    .setTitle(`تَذْكِرَة ${typeLabel}`)
                    .setDescription(`أَهْلاً بِكَ <@${interaction.user.id}> فِي التَّذْكِرَةِ الخَاصَّةِ بِكَ!\n\nيُرْجَى كِتَابَةُ سَبَبِ فَتْحِ التَّذْكِرَةِ وَانْتِظَارُ الرَّدِّ مِنْ قِبَلِ الإِدَارَةِ.`)
                    .setColor('#2f3136')
                    .setTimestamp();

                const controlButtonsRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('ticket_close').setLabel('قفل التكت').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
                    new ButtonBuilder().setCustomId('ticket_claim').setLabel('أستلام التكت').setStyle(ButtonStyle.Secondary).setEmoji('☝️'),
                    new ButtonBuilder().setCustomId('ticket_summon').setLabel('أستدعاء عضو').setStyle(ButtonStyle.Primary).setEmoji('📢')
                );

                // إرسال المنشن خارج الإمبد والإمبد مع الأزرار
                await ticketChannel.send({ 
                    content: `<@${interaction.user.id}> ・ <@&${ADMIN_ROLE_ID}>`,
                    embeds: [innerEmbed],
                    components: [controlButtonsRow] 
                });

                await interaction.editReply({ content: `✅ تَـــــمَّ فَـــــتْـــــح تَـــــذْكِـــــرَتِـــــكَ بِـــــنَـــــجَـــــاح هُـــــنَـــــا: <#${ticketChannel.id}>` });
            } catch (err) { console.error(err); }
        }

        // 1. قفل التكت (للإدارة فقط)
        if (interaction.customId === 'ticket_close') {
            const hasAdmin = interaction.member.roles.cache.has(ADMIN_ROLE_ID) || interaction.member.permissions.has(PermissionFlagsBits.Administrator);
            if (!hasAdmin) {
                return interaction.reply({ content: '❌ **هَذَا الأَمْرُ مُخَصَّصٌ لِلإِدَارَةِ فَقَطْ!**', ephemeral: true });
            }

            await interaction.reply({ content: '🔒 **جَارِي إِغْلَاقُ وَحَذْفُ التَّذْكِرَةِ خِلالَ 5 ثَوَانٍ...**' });
            setTimeout(() => {
                if (interaction?.channel?.id) {
                    ticketClaimers.delete(interaction.channel.id);
                    lastSummonTime.delete(interaction.channel.id);
                    interaction.channel.delete().catch(() => {});
                }
            }, 5000);
        }

        // 2. استلام / إلغاء استلام التكت
        if (interaction.customId === 'ticket_claim' || interaction.customId === 'ticket_unclaim') {
            const hasAdmin = interaction.member.roles.cache.has(ADMIN_ROLE_ID) || interaction.member.permissions.has(PermissionFlagsBits.Administrator);
            if (!hasAdmin) {
                return interaction.reply({ content: '❌ **هَذَا الأَمْرُ مُخَصَّصٌ لِلإِدَارَةِ فَقَطْ!**', ephemeral: true });
            }

            const existingClaimer = ticketClaimers.get(interaction.channel.id);

            // عند الضغط على أستلام التكت
            if (interaction.customId === 'ticket_claim') {
                if (existingClaimer) {
                    return interaction.reply({ 
                        content: `عــذرا ! الــتــكــت مــســتــلــم مــن قِــبَــل <@${existingClaimer}> بــالــفــعــل !`, 
                        ephemeral: true 
                    });
                }

                ticketClaimers.set(interaction.channel.id, interaction.user.id);

                // تغيير زر استلام التكت إلى إلغاء الاستلام
                const updatedRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('ticket_close').setLabel('قفل التكت').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
                    new ButtonBuilder().setCustomId('ticket_unclaim').setLabel('إلغاء أستلام التكت').setStyle(ButtonStyle.Warning).setEmoji('↩️'),
                    new ButtonBuilder().setCustomId('ticket_summon').setLabel('أستدعاء عضو').setStyle(ButtonStyle.Primary).setEmoji('📢')
                );

                await interaction.update({ components: [updatedRow] });
                await interaction.followUp({ content: `☝️ **تَمَّ اسْتِلامُ التَّذْكِرَةِ بِوَاسِطَةِ:** <@${interaction.user.id}>` });
            }

            // عند الضغط على إلغاء أستلام التكت
            if (interaction.customId === 'ticket_unclaim') {
                if (existingClaimer !== interaction.user.id && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return interaction.reply({ content: '❌ **فَقَطْ الشَّخْصُ الَّذِي اسْتَلَمَ التَّذْكِرَةَ يُمْكِنُهُ إِ لْغَاءُ اسْتِلامِهَا!**', ephemeral: true });
                }

                ticketClaimers.delete(interaction.channel.id);

                // إعادة زر استلام التكت إلى وضعه الأصلي
                const originalRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('ticket_close').setLabel('قفل التكت').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
                    new ButtonBuilder().setCustomId('ticket_claim').setLabel('أستلام التكت').setStyle(ButtonStyle.Secondary).setEmoji('☝️'),
                    new ButtonBuilder().setCustomId('ticket_summon').setLabel('أستدعاء عضو').setStyle(ButtonStyle.Primary).setEmoji('📢')
                );

                await interaction.update({ components: [originalRow] });
                await interaction.followUp({ content: `↩️ **تَمَّ إِ لْغَاءُ اسْتِلاَمِ التَّذْكِرَةِ بِوَاسِطَةِ:** <@${interaction.user.id}>` });
            }
        }

        // 3. الاستدعاء (كل ساعتين)
        if (interaction.customId === 'ticket_summon') {
            const lastTime = lastSummonTime.get(interaction.channel.id) || 0;
            const twoHours = 2 * 60 * 60 * 1000;
            const now = Date.now();

            if (now - lastTime < twoHours) {
                const remainingMinutes = Math.ceil((twoHours - (now - lastTime)) / (1000 * 60));
                return interaction.reply({
                    content: `⏰ **عُذْراً! يُنْكِنُكَ اسْتِخْدَامُ الأَمْرِ كُلَّ سَاعَتَيْنِ فَقَطْ. المَتَبَقِّي:** ${remainingMinutes} دَقِيقَةً.`,
                    ephemeral: true
                });
            }

            const modal = new ModalBuilder()
                .setCustomId('summon_modal')
                .setTitle('استدعاء عضو إلى التكت');

            const userInput = new TextInputBuilder()
                .setCustomId('summon_user_input')
                .setLabel('ادخل آيدي العضو أو اليوزر نيم (ID/Username)')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('مثال: 123456789012345678')
                .setRequired(true);

            const firstActionRow = new ActionRowBuilder().addComponents(userInput);
            modal.addComponents(firstActionRow);

            await interaction.showModal(modal);
        }

        // 4. نظام التقديم (مهلة 5 أيام - 5d Cooldown)
        if (interaction.customId === 'ticket_apply') {
            const lastApply = applyCooldowns.get(interaction.user.id) || 0;
            const fiveDays = 5 * 24 * 60 * 60 * 1000;
            const now = Date.now();

            if (now - lastApply < fiveDays) {
                const remainingHours = Math.ceil((fiveDays - (now - lastApply)) / (1000 * 60 * 60));
                return interaction.reply({
                    content: `❌ **عُذْراً! يُنْكِنُكَ التَّقْدِيمُ مَرَّةً كُلَّ 5 أَيَّامٍ فَقَطْ. المَتَبَقِّي:** ${remainingHours} سَاعَةً.`,
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });
            try {
                const dmChannel = await interaction.user.createDM();
                await dmChannel.send('📝 **مَـــــرْحَـــــبًـــــا بِـــــكَ فِـــــي نِـــــظَـــــام اَلـتَّـــــقْـــــدِيـــــم! سَـــــأُرْسِـــــل لَـــــكَ اَلْأَسْـــــئِـــــلَـــــة اَلْآن وَاحِـــــدًا تِـــــلْـــــوَ اَلْآخَـــــر.**');
                await interaction.editReply({ content: '📥 **تَـــــمَّ إِرْسَـــــال اَلْأَسْـــــئِـــــلَـــــة إِلَى خَـــــاصِّـــــكَ اَلْآن!**' });

                const answers = [];
                const dmFilter = m => m.author.id === interaction.user.id;

                for (let i = 0; i < APPLY_QUESTIONS.length; i++) {
                    await dmChannel.send(APPLY_QUESTIONS[i]);
                    const collected = await dmChannel.awaitMessages({ filter: dmFilter, max: 1, time: 300000, errors: ['time'] }).catch(() => null);
                    if (!collected) return;
                    answers.push({ question: APPLY_QUESTIONS[i], answer: collected.first().content });
                }

                applyCooldowns.set(interaction.user.id, Date.now());

                await dmChannel.send('✅ **تَـــــمَّ اِسْـــــتِـــــلَام كُـــــلّ إِجَـــــابَـــــاتِــــ_كَ وَتَـــــحْـــــوِيلِـــــهَـــــا إِلَى لَـــــوْحَـــــة اَلْإِدَارَة بِـــــنَـــــجَـــــاح!**');
                const logChannel = interaction.guild.channels.cache.get(LOG_APPLY_CHANNEL_ID);
                if (logChannel) {
                    const resultEmbed = new EmbedBuilder()
                        .setColor('#2f3136')
                        .setTitle(`📄 تقديم جديد من الخاص للعضو: ${interaction.user.username}`)
                        .setDescription(answers.map((a) => `**${a.question}**\n💬 ${a.answer}`).join('\n\n'));

                    const actionButtons = new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`accept_${interaction.user.id}`).setLabel('قَـــــبُـــــولٌ').setStyle(ButtonStyle.Success).setEmoji('✅'),
                        new ButtonBuilder().setCustomId(`reject_${interaction.user.id}`).setLabel('رَفْـــــــضٌ').setStyle(ButtonStyle.Danger).setEmoji('❌')
                    );
                    await logChannel.send({ content: `🔔 **طَـــــلَـــــبُ تَـــــقْـــــدِيدٍ جَـــــدِيدٍ وَصَـــــالَ لِـــــلْـــــمُــــ_رَاجَـــــعَـــــةِ!** <@&${ADMIN_ROLE_ID}>`, embeds: [resultEmbed], components: [actionButtons] });
                }
            } catch (error) { 
                await interaction.editReply({ content: '❌ **تأَكَّدْ مِنْ فَتْحِ الخَاصِّ لَدَيْكَ لِتَمَكُّنِ البُوتِ مِنْ إِرْسَالِ الأَسْئِلَةِ!**' });
            }
        }

        if (interaction.customId.startsWith('accept_') || interaction.customId.startsWith('reject_')) {
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return;
            await interaction.deferUpdate();
            const action = interaction.customId.startsWith('accept_') ? 'accept' : 'reject';
            const userId = interaction.customId.split('_')[1];
            try {
                const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);
                if (action === 'accept' && targetMember) {
                    for (const roleId of ROLES_TO_GIVE) {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) await targetMember.roles.add(role).catch(() => {});
                    }
                    await targetMember.send(`🎉 **تَـــــهَـــــانِـــــيـــــنَـــــا! تَـــــمَّ قَـــــبُـــــول طَـــــلَـــــب اَلـتَّـــــقْـــــدِيـــــم.**`).catch(() => {});
                }
                const finalEmbed = new EmbedBuilder().setColor(action === 'accept' ? '#2ecc71' : '#e74c3c').setTitle(action === 'accept' ? `✅ تَمَّ قَبُول العُضْوِ` : `❌ تَمَّ رَفْض العُضْوِ`);
                await interaction.message.edit({ embeds: [finalEmbed], components: [] });
            } catch (err) { console.error(err); }
        }
    });
};